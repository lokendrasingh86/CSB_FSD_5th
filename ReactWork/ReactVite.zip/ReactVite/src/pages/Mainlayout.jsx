import React from 'react'

const Mainlayout = () => {
  return (
    <div>Mainlayout</div>
  )
}

export default Mainlayout